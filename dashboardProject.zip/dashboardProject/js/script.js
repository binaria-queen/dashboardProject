document.addEventListener("DOMContentLoaded", function() {
  fetch('data/dados.txt')
  .then(response => response.text())
  .then(data => parseDataAsync(data))
  .then(parsedData => {
      
      const limit = 10000;
      parsedData.categorias = parsedData.categorias.slice(0, limit); 
      parsedData.valores = parsedData.valores.slice(0, limit); 

      console.log("Categorias (Estados):", parsedData.categorias);
      console.log("Valores:", parsedData.valores);
      
     
      const estadosAgrupados = agruparPorEstadoCategoria(parsedData);
      
      
      const comercioFortePorEstado = getComercioForte(estadosAgrupados);
      
     
      const comercioFracoPorEstado = getComercioFraco(estadosAgrupados);
      
      createCharts(estadosAgrupados, comercioFortePorEstado, comercioFracoPorEstado); 
  })
  .catch(error => console.error("Erro ao carregar os dados:", error));

  async function parseDataAsync(data) {
      const linhas = data.split('\n'); 
      const categorias = []; 
      const valores = [];
      const estadosComercio = {}; 

      for (let i = 0; i < linhas.length; i++) {
          const campos = linhas[i].split('\t'); 

          if (campos.length > 10) {
              const estado = campos[3]; 
              const categoria = campos[6]; 
              const valor1 = parseFloat(campos[8]);

             
              if (!isNaN(valor1)) {
                  categorias.push(estado);
                  valores.push(valor1); 
                  
                
                  if (!estadosComercio[estado]) {
                      estadosComercio[estado] = {};
                  }
                  if (!estadosComercio[estado][categoria]) {
                      estadosComercio[estado][categoria] = 0;
                  }
                  estadosComercio[estado][categoria] += valor1;
              }
          }
      }

    
      return { categorias, valores, estadosComercio };
  }


  function agruparPorEstadoCategoria(parsedData) {
      const estadosAgrupados = {
          categorias: [],
          valores: [], 
          comerciosPorEstado: {}
      };

      for (const estado in parsedData.estadosComercio) {
          let totalPorEstado = 0;
          let comerciosEstado = parsedData.estadosComercio[estado];

         
          for (const categoria in comerciosEstado) {
              if (!estadosAgrupados.categorias.includes(estado)) {
                  estadosAgrupados.categorias.push(estado); 
              }
              totalPorEstado += comerciosEstado[categoria]; 

            
              if (!estadosAgrupados.comerciosPorEstado[estado]) {
                  estadosAgrupados.comerciosPorEstado[estado] = [];
              }
              estadosAgrupados.comerciosPorEstado[estado].push({
                  categoria: categoria,
                  valor: comerciosEstado[categoria]
              });
          }

          estadosAgrupados.valores.push(totalPorEstado); 
      }

      return estadosAgrupados;
  }

  
  function getComercioForte(estadosAgrupados) {
      const comercioFortePorEstado = {};

      
      for (const estado in estadosAgrupados.comerciosPorEstado) {
          const comercios = estadosAgrupados.comerciosPorEstado[estado];
          let comercioForte = null;
          let maiorValor = 0;

          for (const comercio of comercios) {
              if (comercio.valor > maiorValor) {
                  maiorValor = comercio.valor;
                  comercioForte = comercio.categoria;
              }
          }
          comercioFortePorEstado[estado] = { categoria: comercioForte, valor: maiorValor };
      }

      return comercioFortePorEstado;
  }

 
  function getComercioFraco(estadosAgrupados) {
      const comercioFracoPorEstado = {};

  
      for (const estado in estadosAgrupados.comerciosPorEstado) {
          const comercios = estadosAgrupados.comerciosPorEstado[estado];
          let comercioFraco = null;
          let menorValor = Infinity;

          for (const comercio of comercios) {
              if (comercio.valor < menorValor) {
                  menorValor = comercio.valor;
                  comercioFraco = comercio.categoria;
              }
          }
          comercioFracoPorEstado[estado] = { categoria: comercioFraco, valor: menorValor }; 
      }

      return comercioFracoPorEstado;
  }

  
function createCharts(data, comercioFortePorEstado) {
  
  const ctxBarra = document.getElementById('graficoBarra').getContext('2d');
  new Chart(ctxBarra, {
      type: 'bar',
      data: {
          labels: data.categorias, 
          datasets: [{
              label: 'Valor Total',
              data: data.valores, 
              backgroundColor: '#4e73df',
              borderColor: '#4e73df',
              borderWidth: 1
          }]
      },
      options: {
          responsive: true,
          scales: {
              y: {
                  beginAtZero: true
              }
          }
      }
  });

  
  const ctxLinha = document.getElementById('graficoLinha').getContext('2d');
  
  
  const estadosLinha = Object.keys(comercioFortePorEstado);
  const categoriasMenosVendidas = estadosLinha.map(estado => comercioFortePorEstado[estado].categoria); 
  const valoresMenosVendidos = estadosLinha.map(estado => comercioFortePorEstado[estado].valor);

  new Chart(ctxLinha, {
      type: 'line',
      data: {
          labels: estadosLinha, 
          datasets: [{
              label: 'Evolução das Categorias Menos Vendidas',
              data: valoresMenosVendidos, 
              borderColor: '#e74c3c', 
              fill: false
          }]
      },
      options: {
          responsive: true,
          scales: {
              y: {
                  beginAtZero: true
              }
          }
      }
  });


  const estados = Object.keys(comercioFortePorEstado);
  const comerciosMaisFortes = estados.map(estado => comercioFortePorEstado[estado].categoria); 
  const valoresComercioForte = estados.map(estado => comercioFortePorEstado[estado].valor); 

  const rotulosCompletos = estados.map(estado => {
      const categoria = comercioFortePorEstado[estado].categoria;
      const valor = comercioFortePorEstado[estado].valor;
      return `${estado} (${valor.toFixed(2)})`; 
  });

  const rotulosCompletos2 = estados.map(estado => {
    const categoria = comercioFortePorEstado[estado].categoria;
      return `${categoria} (${categoria})`; 
});

const ctxPizza = document.getElementById('graficoPizza').getContext('2d');
new Chart(ctxPizza, {
    type: 'pie',
    data: {
        labels: rotulosCompletos,  
        datasets: [{
            label: 'Comércio Mais Forte por Estado',
            data: valoresComercioForte,  
            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f1c40f', '#e74c3c'],
        }]
    },
    options: {
        responsive: true,
        tooltips: {
            callbacks: {
                label: function(tooltipItem, data) {
                    const index = tooltipItem.index;  
                    const estado = data.labels[index].split(' ')[0];  
                    const categoria = comercioFortePorEstado[estado].categoria;  
                    
                   
                    return `${estado} - Categoria mais forte: ${categoria}`;
                },
                
                afterLabel: function(tooltipItem, data) {
                    return ''; 
                }
            }
        }
    }
});


  
  

}  



});
