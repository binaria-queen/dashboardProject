# dashboardProject
Repositório destinado a implementação de um dashboard com JavaScript para visualização de vendas que aconteceram no Brasil em fevereiro de 2019.
